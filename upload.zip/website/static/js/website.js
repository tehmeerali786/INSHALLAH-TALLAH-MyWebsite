
var element = document.getElementById("id_name");
element.classList.add("contactus");

var number = document.getElementById("id_number");
number.classList.add("contactus");


var email = document.getElementById("id_email");
email.classList.add("contactus");

var content = document.getElementById("id_content");
content.classList.add("textarea");
